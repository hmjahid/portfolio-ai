
import React from 'react';

const Skills = () => {
  const frontendSkills = [
    "JavaScript", "React.js", "Next.js", "TypeScript", "HTML5", "CSS3", 
    "Tailwind CSS", "Bootstrap", "Material-UI", "Redux"
  ];
  
  const backendSkills = [
    "Node.js", "Express.js", "MongoDB", "MySQL", "Firebase", "RESTful API", 
    "GraphQL", "Prisma"
  ];
  
  const toolsSkills = [
    "Git", "GitHub", "VS Code", "Figma", "Postman", "Vercel", "Netlify", 
    "AWS", "Docker", "Jest"
  ];

  return (
    <section id="skills" className="section-padding bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="section-title">My Skills</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mt-12">
          <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow animate-fade-in">
            <h3 className="text-xl font-semibold mb-4 text-portfolio-dark">Frontend Development</h3>
            <div className="flex flex-wrap gap-2">
              {frontendSkills.map((skill, index) => (
                <span key={index} className="skill-tag">
                  {skill}
                </span>
              ))}
            </div>
          </div>
          
          <div 
            className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow animate-fade-in" 
            style={{animationDelay: '0.2s'}}
          >
            <h3 className="text-xl font-semibold mb-4 text-portfolio-dark">Backend Development</h3>
            <div className="flex flex-wrap gap-2">
              {backendSkills.map((skill, index) => (
                <span key={index} className="skill-tag">
                  {skill}
                </span>
              ))}
            </div>
          </div>
          
          <div 
            className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow animate-fade-in" 
            style={{animationDelay: '0.4s'}}
          >
            <h3 className="text-xl font-semibold mb-4 text-portfolio-dark">Tools & Technologies</h3>
            <div className="flex flex-wrap gap-2">
              {toolsSkills.map((skill, index) => (
                <span key={index} className="skill-tag">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
